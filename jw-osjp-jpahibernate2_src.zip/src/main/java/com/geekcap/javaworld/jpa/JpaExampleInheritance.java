package com.geekcap.javaworld.jpa;

import com.geekcap.javaworld.jpa.model.Car;
import com.geekcap.javaworld.jpa.model.SportsCar;
import com.geekcap.javaworld.jpa.model.SportsUtilityVehicle;
import org.hibernate.Session;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.util.List;

public class JpaExampleInheritance {
    public static void main(String[] args) {
        // Create our entity manager
        EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("SuperHeroes");
        EntityManager entityManager = entityManagerFactory.createEntityManager();

        SportsCar sportsCar = new SportsCar("Porche", "Carrera", 2018, 150, 4.5);
        SportsUtilityVehicle suv = new SportsUtilityVehicle("Mazda", "CX-9", 2017, true, 3000);
        try {
            entityManager.getTransaction().begin();
            entityManager.persist(sportsCar);
            entityManager.persist(suv);
            entityManager.getTransaction().commit();
        } catch (Exception e) {
            e.printStackTrace();
        }

        List<Car> cars = entityManager.createQuery("from Car").getResultList();
        System.out.println("CARS:");
        cars.forEach(System.out::println);

        // DEBUG, dump our tables
        entityManager.unwrap(Session.class).doWork(connection -> {
            JdbcUtils.dumpTableNames(connection);
//            JdbcUtils.dumpTables(connection, "CAR");
            JdbcUtils.dumpTables(connection, "CAR", "SPORTSCAR", "SUV");
        });

        // Close the entity manager and associated factory
        entityManager.close();
        entityManagerFactory.close();

    }
}
